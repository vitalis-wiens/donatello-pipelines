// here the dynamic imports are required

export default class Pipeline {
  executePipeline = () => {
    console.log("Executing pipeline");
  };
}
