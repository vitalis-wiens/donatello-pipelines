export default class Edge {
  constructor() {
    this.resourceReference = null;
  }
}
