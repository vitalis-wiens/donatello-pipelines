export default class Link {
  constructor() {
    this.resourceReference = null;
  }
}
