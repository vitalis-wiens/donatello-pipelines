This project was generated automatically with Donatello


![Alt Text](https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/46ac665e-75c9-4c16-a2ae-603cc6a673e7/d1ntlle-be8ad027-e59d-46e9-abde-5ad63f7c4f78.gif?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOiIsImlzcyI6InVybjphcHA6Iiwib2JqIjpbW3sicGF0aCI6IlwvZlwvNDZhYzY2NWUtNzVjOS00YzE2LWEyYWUtNjAzY2M2YTY3M2U3XC9kMW50bGxlLWJlOGFkMDI3LWU1OWQtNDZlOS1hYmRlLTVhZDYzZjdjNGY3OC5naWYifV1dLCJhdWQiOlsidXJuOnNlcnZpY2U6ZmlsZS5kb3dubG9hZCJdfQ.avbu9kwZxVsC-70OOLtijMLILshu2aTDGupucjVH9hc)

(original image from https://www.deviantart.com/nichan/art/Tiny-Turtle-Donatello-100478354
)


   


Donatello allows you to create customizable visualization pipelines and export these as react applications.
 
You can find the [Donatello-Project ](https://vitalis-wiens.github.io/donatello-pipelines/) on Github (link to github).
## Description 

To run the demo application run

### `npm install`

then 

### `npm start `
Runs the app in the development mode.<br />
Open [http://localhost:3000](http://localhost:3000) to view it in the browser.
